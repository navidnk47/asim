<?php require("header.php")?>
        <!-- Banner -->
        <div class="section position-relative"
            style="background-image: url(image/dummy-img-1920x900.jpg); height: 70vh;">
            <div class="bg-overlay"></div>
            <div class="r-container h-100 position-relative" style="z-index: 2;">
                <div class="d-flex flex-column w-100 h-100 justify-content-center mx-auto align-items-center text-white gap-3"
                    style="max-width: 895px;">
                    <h2 class="font-1 m-0 text-white fw-bold">About Us</h2>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">About Us</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>

        <!-- Section About Us -->
        <div class="section">
            <div class="r-container">
                <div class="row row-cols-xl-2 row-cols-1">
                    <div class="col col-xl-12 mb-3">
                        
                            <span class="font-2 accent-color">About Us</span>
                        <p> B. R. Gupta & Co. was founded on 1st January, 1988. Mr. B. R. Gupta is the founding partner of the firm B. R. Gupta & Co.He is a practicing Fellow Chartered Accountant (FCA) of the Institute of Chartered Accountants of India with over 54 years of experience.He graduated with a degree in commerce and then went on to complete his degree in law from Delhi University.</p>
                    </div>
                </div>
                <div class="row row-cols-xl-2 row-cols-1">
                    <div class="col col-xl-6 mb-3">
                        <div class="d-flex flex-column">
                            <img src="image/dummy-img-600x800.jpg" alt="image" class="rounded-3 img-fluid me-3">
                            <div class="row row-cols-xl-3 row-cols-1 p-4 bg-accent-primary shadow rounded-3" style="margin-top: -5rem; margin-left: 2rem;">
                                <div class="col mb-3 ps-0 ps-xl-3">
                                    <h3 class="accent-color fw-bold">15<sup>+</sup></h3>
                                    <h6 class="accent-color mb-3">Years Experience</h6>
                                </div>
                                <div class="col mb-3 ps-0">
                                    <h3 class="accent-color fw-bold">85<sup>%</sup></h3>
                                    <h6 class="accent-color">Problem Solved</h6>
                                </div>
                                <div class="col mb-3 ps-0">
                                    <h3 class="accent-color fw-bold">100<sup>+</sup></h3>
                                    <h6 class="accent-color">Expert Accountants</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col col-xl-6 px-4 mb-3">
                        <div class="d-flex flex-column gap-4">
                            <h3 class="fw-bold">OUR VALUE PROPOSITION</h3>
                            <p class="m-0">
                               At B.R. Gupta & Co., we believe that it takes more than a strong performance to build a great company. It also requires an unwavering commitment to our core values and the highest standards of ethics and integrity which drive us and highlight our commitment to:
                            </p>
                            <div class="d-flex flex-column gap-2">
                                <div class="d-flex flex-row gap-3 align-items-center text-color-2 font-2">
                                    <i class="fa-solid fa-circle-check accent-color"></i>
                                    Exceed Client Expectations: To outshine client expectations consistently.
                                </div>
                                <div class="d-flex flex-row gap-3 align-items-center text-color-2 font-2">
                                    <i class="fa-solid fa-circle-check accent-color"></i>
                                    Leadership: To set the highest standards in delivering quality services and be a paradigm for the Industry in which operate.
                                </div>
                                <div class="d-flex flex-row gap-3 align-items-center text-color-2 font-2">
                                    <i class="fa-solid fa-circle-check accent-color"></i>
                                   Transparency and Veracity: To be ethical, sincere and open while rendering our services.
                                </div>
                                <div class="d-flex flex-row gap-3 align-items-center text-color-2 font-2">
                                    <i class="fa-solid fa-circle-check accent-color"></i>
                                    Egalitarianism: To be objective and work-oriented, and thereby earn trust and respect from our clients, our staff and the society.
                                </div>
                                <div class="d-flex flex-row gap-3 align-items-center text-color-2 font-2">
                                    <i class="fa-solid fa-circle-check accent-color"></i>
                                    Excellence: To strive persistently, regularly improve ourselves, our team and our services.
                                </div>
                            </div>
                            

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section Partner -->
        <div class="section bg-accent">
            <div class="r-container">
                <div class="swiper swiperImage">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide p-0">
                            <div class="d-flex justify-content-center">
                                <img src="image/Logo 1.png" class="img-fluid" alt="image">
                            </div>
                        </div>
                        <div class="swiper-slide p-0">
                            <div class="d-flex justify-content-center">
                                <img src="image/Logo 2.png" class="img-fluid " alt="image">
                            </div>
                        </div>
                        <div class="swiper-slide p-0">
                            <div class="d-flex justify-content-center">
                                <img src="image/Logo 3.png" class="img-fluid" alt="image">
                            </div>
                        </div>
                        <div class="swiper-slide p-0">
                            <div class="d-flex justify-content-center">
                                <img src="image/Logo 4.png" class="img-fluid" alt="image">
                            </div>
                        </div>
                        <div class="swiper-slide p-0">
                            <div class="d-flex justify-content-center">
                                <img src="image/Logo 5.png" class="img-fluid" alt="image">
                            </div>
                        </div>
                        <div class="swiper-slide p-0">
                            <div class="d-flex justify-content-center">
                                <img src="image/Logo 6.png" class="img-fluid" alt="image">
                            </div>
                        </div>
                        <div class="swiper-slide p-0">
                            <div class="d-flex justify-content-center">
                                <img src="image/Logo 7.png" class="img-fluid" alt="image">
                            </div>
                        </div>
                    </div>
                    <!-- If we need pagination -->
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </div>

        <!-- Section Services -->
        <div class="section" style="background-image: url(image/Background.png);">
            <div class="r-container">
                <div class="row row-cols-xl-3 row-cols-1">
                    <div class="col col-xl-4 mb-3">
                        <div class="d-flex flex-column gap-3">
                            <span class="font-2 accent-color">Support Services</span>
                            <h3 class="fw-bold">The Best Option For Your Finances</h3>
                            <p>
                                We specialize in providing comprehensive financial services tailored to meet the unique
                                needs of our clients.
                            </p>
                            <div class="w-max-content">
                                <a href="services.html"
                                    class="btn btn-accent rounded-2 d-flex flex-row gap-2 px-5 py-3">
                                    All Services
                                </a>
                            </div>
                            <div class="d-flex flex-column gap-3 ps-2 mt-3">
                                <div class=" col position-relative">
                                    <div class=" d-flex flex-row customer-container">
                                        <div class="customer-item">
                                            <img src="image/dummy-img-400x400.jpg" class="img-fluid" alt="">
                                        </div>
                                        <div class="customer-item">
                                            <img src="image/dummy-img-400x400.jpg" class="img-fluid" alt="">
                                        </div>
                                        <div class="customer-item">
                                            <img src="image/dummy-img-400x400.jpg" class="img-fluid" alt="">
                                        </div>
                                    </div>
                                </div>
                                <span class="m-0 accent-color">90% Satisfied clients</span>
                            </div>
                        </div>
                    </div>
                    <div class="col col-xl-8 mb-3">
                        <div class="row row-cols-xl-2 row-cols-1">
                            <div class="col mb-3">
                                <div class="card card-service img-hover h-100 shadow">
                                    <div class=" d-flex flex-column gap-3 px-4 py-5">
                                        <div class="d-flex flex-row gap-3 align-items-center">
                                            <div class="icon-box-2">
                                                <i class="rtmicon rtmicon-taxation accent-color"
                                                    style="font-size: 60px;"></i>
                                            </div>
                                            <h4 class="accent-color">Tax planning</h4>
                                        </div>
                                        <p class="m-0">Our payroll processing services take the hassle out of managing
                                            your payroll, allowing you to focus on running your business.</p>
                                        <a href="service_detail.html" class="read-more">
                                            <div class="d-flex flex-row gap-3 align-items-center">
                                                <span>Read More</span>
                                                <i class="rtmicon rtmicon-chevron-right fs-6 fw-bold"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col mb-3">
                                <div class="card card-service img-hover h-100 shadow">
                                    <div class=" d-flex flex-column gap-3 px-4 py-5">
                                        <div class="d-flex flex-row gap-3 align-items-center">
                                            <div class="icon-box-2">
                                                <i class="rtmicon rtmicon-taxes accent-color"
                                                    style="font-size: 60px;"></i>
                                            </div>
                                            <h4 class="accent-color">Audit services</h4>
                                        </div>
                                        <p class="m-0">Our payroll processing services take the hassle out of managing
                                            your payroll, allowing you to focus on running your business.</p>
                                        <a href="service_detail.html" class="read-more">
                                            <div class="d-flex flex-row gap-3 align-items-center">
                                                <span>Read More</span>
                                                <i class="rtmicon rtmicon-chevron-right fs-6 fw-bold"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col mb-3">
                                <div class="card card-service img-hover h-100 shadow">
                                    <div class=" d-flex flex-column gap-3 px-4 py-5">
                                        <div class="d-flex flex-row gap-3 align-items-center">
                                            <div class="icon-box-2">
                                                <i class="rtmicon rtmicon-tax-law accent-color"
                                                    style="font-size: 60px;"></i>
                                            </div>
                                            <h4 class="accent-color">Tax strategy</h4>
                                        </div>
                                        <p class="m-0">Our payroll processing services take the hassle out of managing
                                            your payroll, allowing you to focus on running your business.</p>
                                        <a href="service_detail.html" class="read-more">
                                            <div class="d-flex flex-row gap-3 align-items-center">
                                                <span>Read More</span>
                                                <i class="rtmicon rtmicon-chevron-right fs-6 fw-bold"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col mb-3">
                                <div class="card card-service img-hover h-100 shadow">
                                    <div class=" d-flex flex-column gap-3 px-4 py-5">
                                        <div class="d-flex flex-row gap-3 align-items-center">
                                            <div class="icon-box-2">
                                                <i class="rtmicon rtmicon-money-check accent-color"
                                                    style="font-size: 60px;"></i>
                                            </div>
                                            <h4 class="accent-color">Bookkeeping</h4>
                                        </div>
                                        <p class="m-0">Our payroll processing services take the hassle out of managing
                                            your payroll, allowing you to focus on running your business.</p>
                                        <a href="service_detail.html" class="read-more">
                                            <div class="d-flex flex-row gap-3 align-items-center">
                                                <span>Read More</span>
                                                <i class="rtmicon rtmicon-chevron-right fs-6 fw-bold"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section CTA -->
        <div class="section position-relative bg-attach-fixed"
            style="background-image: url(image/dummy-img-1920x900.jpg); height: 70vh;">
            <div class="bg-overlay"></div>
            <div class="r-container h-100 position-relative" style="z-index: 2;">
                <div class="d-flex flex-column mx-auto text-center w-100 h-100 justify-content-center align-items-center text-white gap-4"
                    style="max-width: 767px;">
                    <h3 class="font-1 text-white">Achieve Financial Freedom
                        Book a Free Assessment Now!</h3>
                    <p  class="text-white" style="max-width: 667px;">
                        We specialize in providing comprehensive financial services tailored to meet the unique needs of
                        our clients.
                    </p>
                    <div class="w-max-content">
                        <a href="contact.html" class="btn btn-accent rounded-2 d-flex flex-row gap-2 px-5 py-3">
                            Contact Us
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Team -->
        <div class="section">
            <div class="r-container">
                <div class="d-flex flex-column gap-4 align-items-center">
                    <div class="d-flex flex-column gap-3 text-center align-items-center" style="max-width: 667px;">
                        <span class="font-2 accent-color">Our Team</span>
                        <h3 class="fw-bold">Meet Our Accountants Experts</h3>
                        <p>
                            We specialize in providing comprehensive financial services tailored to meet the unique
                            needs of our clients.
                        </p>
                    </div>
                    <div class="row row-cols-xl-3 row-cols-1">
                        <div class="col mb-3">
                            <img src="image/dummy-img-600x700.jpg" alt="image" class="img-fluid rounded-top-3 w-100">
                            <div
                                class="bg-accent-color d-flex flex-column text-white p-4 align-items-center text-center rounded-bottom-3">
                                <div class="mb-2">
                                    <h5>Ryan Collin</h5>
                                    <span class="font-2">Senior Accountant</span>
                                </div>
                                <div class="social-container team gap-2">
                                    <a href="https://www.facebook.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-facebook-f"></i>
                                    </a>
                                    <a href="https://www.twitter.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-twitter"></i>
                                    </a>
                                    <a href="https://www.instagram.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-instagram"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-3">
                            <img src="image/dummy-img-600x700.jpg" alt="image" class="img-fluid rounded-top-3 w-100">
                            <div
                                class="bg-accent-color d-flex flex-column text-white p-4 align-items-center text-center rounded-bottom-3">
                                <div class="mb-2">
                                    <h5>Rihanna Cloudy</h5>
                                    <span class="font-2">Budget Analyst</span>
                                </div>
                                <div class="social-container team gap-2">
                                    <a href="https://www.facebook.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-facebook-f"></i>
                                    </a>
                                    <a href="https://www.twitter.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-twitter"></i>
                                    </a>
                                    <a href="https://www.instagram.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-instagram"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-3">
                            <img src="image/dummy-img-600x700.jpg" alt="image" class="img-fluid rounded-top-3 w-100">
                            <div
                                class="bg-accent-color d-flex flex-column text-white p-4 align-items-center text-center rounded-bottom-3">
                                <div class="mb-2">
                                    <h5>Abraham Deanz</h5>
                                    <span class="font-2">Tax Expert</span>
                                </div>
                                <div class="social-container team gap-2">
                                    <a href="https://www.facebook.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-facebook-f"></i>
                                    </a>
                                    <a href="https://www.twitter.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-twitter"></i>
                                    </a>
                                    <a href="https://www.instagram.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-instagram"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="w-max-content">
                        <a href="team.html" class="btn btn-accent rounded-2 d-flex flex-row gap-2 px-5 py-3">
                            All Team
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Testimonials -->
        <div class="section bg-accent">
            <div class="r-container d-flex flex-column gap-4">
                <div class="row row-cols-xl-2 row-cols-1">
                    <div class="col col-xl-5 mb-3">
                        <img src="image/dummy-img-600x700.jpg" class="img-fluid rounded-3 h-100" alt="">
                    </div>
                    <div class="col col-xl-7 mb-3">
                        <div class="d-flex flex-column gap-3 mx-auto" style="max-width: 667px;">
                            <span class="font-2 accent-color">Testimonials</span>
                            <h3 class="fw-bold">Client Testimonials Highlighting Pluz's Impact</h3>
                            <p>
                                We specialize in providing comprehensive financial services tailored to meet the unique
                                needs of our clients.
                            </p>
                        </div>
                        <div class="overflow-hidden floating-left mt-3">
                            <div class="swiper swiperTestimonials">
                                <!-- Additional required wrapper -->
                                <div class="swiper-wrapper">
                                    <!-- Slides -->
                                    <div class="swiper-slide">
                                        <div
                                            class="testimonial-container text-white px-5 py-5 border border-1 border-accent-color rounded-3 justify-content-between">
                                            <div class="d-flex flex-column gap-3">
                                                <span class="font-2 fst-italic">"“Working with Pluz Accounting has been
                                                    a game-changer for our small business. Their meticulous attention to
                                                    detail and proactive tax planning have saved us.”</span>
                                                <div class="d-flex flex-row justify-content-between align-items-center">
                                                    <div class="d-flex flex-row align-items-center gap-3">
                                                        <div class="testimonial-item">
                                                            <img src="image/dummy-img-400x400.jpg"
                                                                class="img-fluid border-light" alt="">
                                                        </div>
                                                        <div class="d-flex flex-column">
                                                            <h5>Sarah Laura</h5>
                                                            <span class="font-2 text-color-2">Designation</span>
                                                            <div class="flex-row">
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star"
                                                                    style="color: var(--text-color-1);"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <i class="rtmicon rtmicon-blockquote fw-bold accent fs-1"></i>
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div
                                            class="testimonial-container text-white px-5 py-5 border border-1 border-accent-color rounded-3 justify-content-between">
                                            <div class="d-flex flex-column gap-3">
                                                <span class="font-2 fst-italic">"“Working with Pluz Accounting has been
                                                    a game-changer for our small business. Their meticulous attention to
                                                    detail and proactive tax planning have saved us.”</span>
                                                <div class="d-flex flex-row justify-content-between align-items-center">
                                                    <div class="d-flex flex-row align-items-center gap-3">
                                                        <div class="testimonial-item">
                                                            <img src="image/dummy-img-400x400.jpg"
                                                                class="img-fluid border-light" alt="">
                                                        </div>
                                                        <div class="d-flex flex-column">
                                                            <h5>Thomas Roy</h5>
                                                            <span class="font-2 text-color-2">Designation</span>
                                                            <div class="flex-row">
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star"
                                                                    style="color: var(--text-color-1);"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <i class="rtmicon rtmicon-blockquote fw-bold accent fs-1"></i>
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div
                                            class="testimonial-container text-white px-5 py-5 border border-1 border-accent-color rounded-3 justify-content-between">
                                            <div class="d-flex flex-column gap-3">
                                                <span class="font-2 fst-italic">"“Working with Pluz Accounting has been
                                                    a game-changer for our small business. Their meticulous attention to
                                                    detail and proactive tax planning have saved us.”</span>
                                                <div class="d-flex flex-row justify-content-between align-items-center">
                                                    <div class="d-flex flex-row align-items-center gap-3">
                                                        <div class="testimonial-item">
                                                            <img src="image/dummy-img-400x400.jpg"
                                                                class="img-fluid border-light" alt="">
                                                        </div>
                                                        <div class="d-flex flex-column">
                                                            <h5>John Thunder</h5>
                                                            <span class="font-2 text-color-2">Designation</span>
                                                            <div class="flex-row">
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star"
                                                                    style="color: var(--text-color-1);"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <i class="rtmicon rtmicon-blockquote fw-bold accent fs-1"></i>
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <!-- If we need pagination -->
                                <div class="swiper-pagination"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section Pricing Plan -->
        <div class="section">
            <div class="r-container">
                <div class="d-flex flex-column gap-4 align-items-center">
                    <div class="row row-cols-xl-2 row-cols-1 align-items-center">
                        <div class="col">
                            <span class="font-2 accent-color">Pricing Plan</span>
                            <h3 class="fw-bold">The Best Price For You</h3>
                        </div>
                        <div class="col">
                            <p>
                                We specialize in providing comprehensive financial services tailored to meet the unique
                                needs of our clients.
                            </p>
                        </div>
                    </div>
                    <div class="row row-cols-xl-3 row-cols-1">
                        <div class="col mb-3">
                            <div class="card card-outline-hover h-100 p-5">
                                <div class="d-flex flex-column gap-3">
                                    <div class="d-flex flex-row justify-content-between align-items-center">
                                        <div class="d-flex flex-column gap-3">
                                            <h5 class="accent-color fw-semibold">Starter</h5>
                                            <div class="d-flex flex-row align-items-end heading mb-3">
                                                <h3 class="m-0 fw-bold">$49</h3>
                                                <span class="fw-semibold">/Month</span>
                                            </div>
                                        </div>
                                        <div class="icon-box-2">
                                            <i class="rtmicon rtmicon-money-bill accent-color"
                                                style="font-size: 60px;"></i>
                                        </div>
                                    </div>
                                    <span class="text-color-2">Nam ultrices lacus interdum neque sagittis met Integer
                                        porta sem eu facilisis.</span>
                                    <div class="d-flex flex-column gap-2">
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Morbi aliquet ex sit amet pretium.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Vivamus sit amet erat turpis.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Phasellus eu porta dolor.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Nam mattis pellentesque sem.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Pellentesque lorem est.
                                        </div>
                                    </div>
                                    <div class="w-100">
                                        <a href="contact.html"
                                            class="btn btn-accent rounded-2 d-flex flex-row gap-2 px-5 py-3">
                                            Get Started
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-3">
                            <div class="card card-outline-hover h-100 p-5">
                                <div class="d-flex flex-column gap-3">
                                    <div class="d-flex flex-row justify-content-between align-items-center">
                                        <div class="d-flex flex-column gap-3">
                                            <h5 class="accent-color fw-semibold">Enterprise</h5>
                                            <div class="d-flex flex-row align-items-end heading mb-3">
                                                <h3 class="m-0 fw-bold">$129</h3>
                                                <span class="fw-semibold">/Month</span>
                                            </div>
                                        </div>
                                        <div class="icon-box-2">
                                            <i class="rtmicon rtmicon-money-bill accent-color"
                                                style="font-size: 60px;"></i>
                                        </div>
                                    </div>
                                    <span class="text-color-2">Nam ultrices lacus interdum neque sagittis met Integer
                                        porta sem eu facilisis.</span>
                                    <div class="d-flex flex-column gap-2">
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Morbi aliquet ex sit amet pretium.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Vivamus sit amet erat turpis.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Phasellus eu porta dolor.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Nam mattis pellentesque sem.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Pellentesque lorem est.
                                        </div>
                                    </div>
                                    <div class="w-100">
                                        <a href="contact.html"
                                            class="btn btn-accent rounded-2 d-flex flex-row gap-2 px-5 py-3">
                                            Get Started
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-3">
                            <div class="card card-outline-hover h-100 p-5">
                                <div class="d-flex flex-column gap-3">
                                    <div class="d-flex flex-row justify-content-between align-items-center">
                                        <div class="d-flex flex-column gap-3">
                                            <h5 class="accent-color fw-semibold">Professional</h5>
                                            <div class="d-flex flex-row align-items-end heading mb-3">
                                                <h3 class="m-0 fw-bold">$90</h3>
                                                <span class="fw-semibold">/Month</span>
                                            </div>
                                        </div>
                                        <div class="icon-box-2">
                                            <i class="rtmicon rtmicon-money-bill accent-color"
                                                style="font-size: 60px;"></i>
                                        </div>
                                    </div>
                                    <span class="text-color-2">Nam ultrices lacus interdum neque sagittis met Integer
                                        porta sem eu facilisis.</span>
                                    <div class="d-flex flex-column gap-2">
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Morbi aliquet ex sit amet pretium.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Vivamus sit amet erat turpis.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Phasellus eu porta dolor.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Nam mattis pellentesque sem.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Pellentesque lorem est.
                                        </div>
                                    </div>
                                    <div class="w-100">
                                        <a href="contact.html"
                                            class="btn btn-accent rounded-2 d-flex flex-row gap-2 px-5 py-3">
                                            Get Started
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php require("footer.php")?>