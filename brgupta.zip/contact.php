<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" type="image/x-icon" href="image/logo.png">
    <title>Pluz - Contact Us</title>
</head>

<body>
    <!-- Scripts -->
    <script src="js/vendor/jquery.min.js"></script>

    <!-- Header -->
    <div class="bg-text-color py-3">
        <div class="r-container">
            <div
                class="d-flex flex-xl-row flex-column justify-content-center justify-content-xl-between text-white align-items-center font-2">
                <span class="d-flex flex-row align-items-center gap-2">
                    <i class="rtmicon rtmicon-classic-phone text-white"></i>
                    0761-8523-398
                </span>
                <span class="d-flex flex-row align-items-center gap-2">
                    <i class="rtmicon rtmicon-location text-white"></i>
                    KLLG St, No.99, Pku City, ID 28289
                </span>
                <span class="d-flex flex-row align-items-center gap-2">
                    <i class="rtmicon rtmicon-envelope text-white"></i>
                    hello@domainsite.com
                </span>
            </div>
        </div>
    </div>
    <header class="sticky-top bg-accent-primary">
        <div class="r-container">
            <nav class="navbar navbar-expand-xl">
                <div class="container-fluid ps-3">
                    <div class="logo-container">
                        <a class="navbar-brand" href="#"><img src="image/logo.png" alt="" class="img-fluid"></a>
                    </div>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fa-solid fa-bars-staggered accent-color-2"></i>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav mx-auto mb-2 mb-xl-0 gap-xl-4 gap-1">
                            <li class="nav-item">
                                <a class="nav-link" aria-current="page" href="index.html">Homepage</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    About Us
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="about.html">About Us</a></li>
                                    <li><a class="dropdown-item" href="team.html">Team</a></li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    Services
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="services.html">Services</a></li>
                                    <li><a class="dropdown-item" href="service_detail.html">Service Details</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    Pages
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="price_plan.html">Pricing Plan</a></li>
                                    <li><a class="dropdown-item" href="faq.html">FAQs</a></li>
                                    <li><a class="dropdown-item" href="404.html">404 Error</a></li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    News
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="blog.html">Last Article</a></li>
                                    <li><a class="dropdown-item" href="single_blog.html">Single Post</a></li>
                                </ul>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="contact.html">Contact Us</a>
                            </li>
                        </ul>
                        <div
                            class="d-flex flex-row align-items-center text-xl-start text-center justify-content-center gap-3">
                            <div class="contact-item">
                                <i class="rtmicon rtmicon-classic-phone fs-4"></i>
                            </div>
                            <div class="d-flex flex-column">
                                <span class="font-2">Call any time</span>
                                <span class="font-2">0761-8523-398</span>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
        </div>
    </header>
    <!-- End Header -->

    <!-- Main -->
    <main>
        <!-- Banner -->
        <div class="section position-relative"
            style="background-image: url(image/dummy-img-1920x900.jpg); height: 70vh;">
            <div class="bg-overlay"></div>
            <div class="r-container h-100 position-relative" style="z-index: 2;">
                <div class="d-flex flex-column w-100 h-100 justify-content-center mx-auto align-items-center text-white gap-3"
                    style="max-width: 895px;">
                    <h2 class="font-1 m-0 text-white fw-bold">Contact Us</h2>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>

        <!-- Section Contact Us -->
        <div class="section">
            <div class="r-container">
                <div class="row row-cols-xl-3 row-cols-1">
                    <div class="col mb-3">
                        <div class="card card-service img-hover h-100 shadow">
                            <div class=" d-flex flex-column gap-3 justify-content-center p-5">
                                <div class="icon-box">
                                    <i class="rtmicon rtmicon-classic-phone" style="font-size: 30px;"></i>
                                </div>
                                <h4 class="accent-color">Give us a call</h4>
                                <p class="text-color-2">Lorem ipsum dolor sit amert et consectur ultraes elitsedo
                                    adipiscing sem.</p>
                                <h6 class="text-color">0761-8523-398</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-3">
                        <div class="card card-service img-hover h-100 shadow">
                            <div class=" d-flex flex-column gap-3 justify-content-center p-5">
                                <div class="icon-box">
                                    <i class="rtmicon rtmicon-envelope" style="font-size: 30px;"></i>
                                </div>
                                <h4 class="accent-color">Send us an email</h4>
                                <p class="text-color-2">Lorem ipsum dolor sit amert et consectur ultraes elitsedo
                                    adipiscing sem.</p>
                                <h6 class="text-color">hello@domainsite.com</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-3">
                        <div class="card card-service img-hover h-100 shadow">
                            <div class=" d-flex flex-column gap-3 justify-content-center p-5">
                                <div class="icon-box">
                                    <i class="rtmicon rtmicon-location" style="font-size: 30px;"></i>
                                </div>
                                <h4 class="accent-color">Visit Our Office</h4>
                                <p class="text-color-2">Lorem ipsum dolor sit amert et consectur ultraes elitsedo
                                    adipiscing sem.</p>
                                <h6 class="text-color">KLLG St, No.99, Pku City, ID 28289</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="section pt-0">
            <div class="r-container">
                <div class="row row-cols-xl-2 row-cols-1">
                    <div class="col col-xl-4 mb-3">
                        <div class="d-flex flex-column gap-3 h-100 justify-content-center pe-xl-3">
                            <div class="d-flex flex-column gap-3">
                                <span class="font-2 accent-color">Contact Us</span>
                                <h3 class="fw-bold">Get In Touch</h3>
                                <p>
                                    Ipsum est urna tellus varius risus a vitae tempor rhoncus vitae neque massa eu mi
                                    velit elementum enim ad minim veniam quis nostrud exercitation.
                                </p>
                            </div>
                            <div class="d-flex flex-column gap-3">
                                <h5>Follow Us On:</h5>
                                <div class="social-container team mb-xl-0 mb-3 gap-2">
                                    <a href="https://www.facebook.com" class="social-item-2">
                                        <i class="fa-brands fa-xs fa-facebook-f"></i>
                                    </a>
                                    <a href="https://www.twitter.com" class="social-item-2">
                                        <i class="fa-brands fa-xs fa-twitter"></i>
                                    </a>
                                    <a href="https://www.instagram.com" class="social-item-2">
                                        <i class="fa-brands fa-xs fa-instagram"></i>
                                    </a>
                                    <a href="https://www.youtube.com" class="social-item-2">
                                        <i class="fa-brands fa-xs fa-youtube"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col col-xl-8 mb-3">
                        <div class="d-flex flex-column p-5 rounded-4 w-100 shadow">
                            <div class="success_msg toast align-items-center w-100 shadow-none mb-3 border border-success rounded-pill my-4"
                                role="alert" aria-live="assertive" aria-atomic="true">
                                <div class="d-flex p-2">
                                    <div class="toast-body f-18 d-flex flex-row gap-3 align-items-center text-success">
                                        <i class="fa-solid fa-check f-36 text-success"></i>
                                        Your Message Successfully Send.
                                    </div>
                                    <button type="button"
                                        class="me-2 m-auto bg-transparent border-0 ps-1 pe-0 text-success"
                                        data-bs-dismiss="toast" aria-label="Close"><i
                                            class="fa-solid fa-xmark"></i></button>
                                </div>
                            </div>
                            <div class="error_msg toast align-items-center w-100 shadow-none border-danger mb-3 my-4 border rounded-pill"
                                role="alert" aria-live="assertive" aria-atomic="true">
                                <div class="d-flex p-2">
                                    <div class="toast-body f-18 d-flex flex-row gap-3 align-items-center text-danger">
                                        <i class="fa-solid fa-triangle-exclamation f-36 text-danger"></i>
                                        Something Wrong ! Send Form Failed.
                                    </div>
                                    <button type="button"
                                        class="me-2 m-auto bg-transparent border-0 ps-1 pe-0 text-danger"
                                        data-bs-dismiss="toast" aria-label="Close"><i
                                            class="fa-solid fa-xmark"></i></button>
                                </div>
                            </div>
                            <form
                                class="d-flex flex-column h-100 justify-content-center px-4 w-100 needs-validation form"
                                novalidate>
                                <div class="mb-3">
                                    <input type="text" class="form-control py-3 px-4 rounded-3" name="name" id="name"
                                        placeholder="Name" required>
                                    <div class="invalid-feedback">
                                        The field is required.
                                    </div>
                                </div>
                                <div class="row row-cols-xl-2 row-cols-1">
                                    <div class="col mb-3">
                                        <input type="email" class="form-control py-3 px-4 rounded-3" name="email" id="email"
                                            placeholder="Email" required>
                                        <div class="invalid-feedback">
                                            The field is required.
                                        </div>
                                    </div>
                                    <div class="col mb-3">
                                        <input type="tel" class="form-control py-3 px-4 rounded-3" name="phone" id="phone"
                                            placeholder="Phone" required>
                                        <div class="invalid-feedback">
                                            The field is required.
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <textarea class="form-control py-3 px-4 rounded-3" id="message" name="message" rows="5"
                                        placeholder="Message"></textarea>
                                </div>
                                <div>
                                    <button type="submit"
                                        class="btn btn-accent submit_form py-3 w-100 d-flex justify-content-center gap-2 rounded-3">
                                        Send Message
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="section p-0">
            <iframe loading="lazy" class="maps overflow-hidden"
                src="https://maps.google.com/maps?q=London%20Eye%2C%20London%2C%20United%20Kingdom&amp;t=m&amp;z=14&amp;output=embed&amp;iwloc=near"
                title="London Eye, London, United Kingdom" aria-label="London Eye, London, United Kingdom"></iframe>
        </div>

    </main>

    <footer>
        <div class="section pb-0 bg-accent">
            <div class="r-container">
                <div class="border-bottom border-accent-color pb-xl-5 pb-0">
                    <div class="row row-cols-xl-3 row-cols-1">
                        <div class="col col-xl-4 mb-3">
                            <div class="d-flex flex-column gap-3 pe-xl-5">
                                <img src="image/logo.png" alt="" class="img-fluid" width="250">
                                <p>
                                    Tristirue nulla aliquet enim tortor at auctor urnanmassa enim nec dui nunc mattis
                                    enim ut tellusnaute irure repreaen. 
                                </p>
                                <div class="social-container mb-xl-0">
                                    <a href="https://www.facebook.com" class="social-item-2">
                                        <i class="fa-brands fa-xs fa-facebook-f"></i>
                                    </a>
                                    <a href="https://www.twitter.com" class="social-item-2">
                                        <i class="fa-brands fa-xs fa-twitter"></i>
                                    </a>
                                    <a href="https://www.instagram.com" class="social-item-2">
                                        <i class="fa-brands fa-xs fa-instagram"></i>
                                    </a>
                                    <a href="https://www.youtube.com" class="social-item-2">
                                        <i class="fa-brands fa-xs fa-youtube"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col col-xl-8 mb-3">
                            <div class="row row-cols-xl-3 row-cols-1">
                                <div class="col-xl-3 mb-3">
                                    <div class="d-flex flex-column gap-3">
                                        <div class="pb-2 w-max-content border-bottom border-accent-2">
                                            <h5 class="font-1 accent-color">Navigation</h5>
                                        </div>
                                        <ul class="list ps-0 gap-2 accent-color">
                                            <li>
                                                <a href="" class="link d-flex flex-row gap-3 align-items-center">
                                                    Home
                                                </a>
                                            </li>
                                            <li>
                                                <a href="" class="link d-flex flex-row gap-3 align-items-center">
                                                    About Us
                                                </a>
                                            </li>
                                            <li>
                                                <a href="" class="link d-flex flex-row gap-3 align-items-center">
                                                    Services
                                                </a>
                                            </li>
                                            <li>
                                                <a href="" class="link d-flex flex-row gap-3 align-items-center">
                                                    Pages
                                                </a>
                                            </li>
                                            <li>
                                                <a href="" class="link d-flex flex-row gap-3 align-items-center">
                                                    Blog
                                                </a>
                                            </li>
                                            <li>
                                                <a href="" class="link d-flex flex-row gap-3 align-items-center">
                                                    Contact Us
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-xl-4 mb-3">
                                    <div class="d-flex flex-column gap-3">
                                        <div class="pb-2 w-max-content border-bottom border-accent-2">
                                            <h5 class="font-1 accent-color">Working Hours</h5>
                                        </div>
                                        <ul class="list gap-2">
                                            <li class="d-flex flex-column">
                                                <span>Monday – Saturday</span>
                                                <span>12:00 pm – 14:45 pm</span>
                                            </li>
                                            <li class="d-flex flex-column">
                                                <span>Sunday – Thursday</span>
                                                <span>17.30 pm – 00.00 am</span>
                                            </li>
                                            <li class="d-flex flex-column">
                                                <span>Friday – Saturday</span>
                                                <span>17.30 pm – 00.00 am</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-xl-5 mb-xl-3 mb-0">
                                    <div class="d-flex flex-column gap-3">
                                        <div class="pb-2 w-max-content border-bottom border-accent-2">
                                            <h5 class="font-1 accent-color">Contact Us</h5>
                                        </div>
                                        <div class="d-flex flex-column gap-3">
                                            <span class="d-flex flex-row align-items-center font-2 gap-3">
                                                <div class="contact-item">
                                                    <i class="rtmicon rtmicon-location fs-4"></i>
                                                </div>
                                                KLLG st, No.99, Pku City, ID 28289
                                            </span>
                                            <span class="d-flex flex-row align-items-center font-2 gap-3">
                                                <div class="contact-item">
                                                    <i class="rtmicon rtmicon-envelope fs-4"></i>
                                                </div>
                                                hello@domainsite.com
                                            </span>
                                            <span class="d-flex flex-row align-items-center font-2 gap-3">
                                                <div class="contact-item">
                                                    <i class="rtmicon rtmicon-classic-phone  fs-4"></i>
                                                </div>
                                                0761-8523-398
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section d-flex flex-xl-row flex-column gap-3 justify-content-center py-3">
                    <span class="text-xl-center accent-color text-center fs-6 font-2">
                        Copyright © 2024 Rometheme. All Rights Reserved.
                    </span>
                </div>
            </div>
        </div>
    </footer>

    <script src="js/vendor/bootstrap.bundle.min.js"></script>
    <script src="js/vendor/swiper-bundle.min.js"></script>
    <script src="js/script.js"></script>
    <script src="js/swiper-script.js"></script>
    <script src="js/submit-form.js"></script>
    <script src="js/vendor/isotope.pkgd.min.js"></script>
    <script src="js/video_embedded.js"></script>
    <script src="js/vendor/fslightbox.js"></script>
</body>

</html>