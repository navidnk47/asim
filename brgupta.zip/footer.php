 </main>

    <footer>
        <div class="section pb-0 bg-accent">
            <div class="r-container">
                <div class="border-bottom border-accent-color pb-xl-5 pb-0">
                    <div class="row row-cols-xl-3 row-cols-1">
                        <div class="col col-xl-4 mb-3">
                            <div class="d-flex flex-column gap-3 pe-xl-5">
                                <img src="image/brgupta.png" alt="" class="img-fluid" width="250">
                                <p>
                                    Tristirue nulla aliquet enim tortor at auctor urnanmassa enim nec dui nunc mattis
                                    enim ut tellusnaute irure repreaen. 
                                </p>
                                <div class="social-container mb-xl-0">
                                    <a href="https://www.facebook.com" class="social-item-2">
                                        <i class="fa-brands fa-xs fa-facebook-f"></i>
                                    </a>
                                    <a href="https://www.twitter.com" class="social-item-2">
                                        <i class="fa-brands fa-xs fa-twitter"></i>
                                    </a>
                                    <a href="https://www.instagram.com" class="social-item-2">
                                        <i class="fa-brands fa-xs fa-instagram"></i>
                                    </a>
                                    <a href="https://www.youtube.com" class="social-item-2">
                                        <i class="fa-brands fa-xs fa-youtube"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col col-xl-8 mb-3">
                            <div class="row row-cols-xl-3 row-cols-1">
                                <div class="col-xl-3 mb-3">
                                    <div class="d-flex flex-column gap-3">
                                        <div class="pb-2 w-max-content border-bottom border-accent-2">
                                            <h5 class="font-1 accent-color">Navigation</h5>
                                        </div>
                                        <ul class="list ps-0 gap-2 accent-color">
                                            <li>
                                                <a href="" class="link d-flex flex-row gap-3 align-items-center">
                                                    Home
                                                </a>
                                            </li>
                                            <li>
                                                <a href="" class="link d-flex flex-row gap-3 align-items-center">
                                                    About Us
                                                </a>
                                            </li>
                                            <li>
                                                <a href="" class="link d-flex flex-row gap-3 align-items-center">
                                                    Services
                                                </a>
                                            </li>
                                            <li>
                                                <a href="" class="link d-flex flex-row gap-3 align-items-center">
                                                    Pages
                                                </a>
                                            </li>
                                            <li>
                                                <a href="" class="link d-flex flex-row gap-3 align-items-center">
                                                    Blog
                                                </a>
                                            </li>
                                            <li>
                                                <a href="" class="link d-flex flex-row gap-3 align-items-center">
                                                    Contact Us
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-xl-4 mb-3">
                                    <div class="d-flex flex-column gap-3">
                                        <div class="pb-2 w-max-content border-bottom border-accent-2">
                                            <h5 class="font-1 accent-color">Working Hours</h5>
                                        </div>
                                        <ul class="list gap-2">
                                            <li class="d-flex flex-column">
                                                <span>Monday – Saturday</span>
                                                <span>12:00 pm – 14:45 pm</span>
                                            </li>
                                            <li class="d-flex flex-column">
                                                <span>Sunday – Thursday</span>
                                                <span>17.30 pm – 00.00 am</span>
                                            </li>
                                            <li class="d-flex flex-column">
                                                <span>Friday – Saturday</span>
                                                <span>17.30 pm – 00.00 am</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-xl-5 mb-xl-3 mb-0">
                                    <div class="d-flex flex-column gap-3">
                                        <div class="pb-2 w-max-content border-bottom border-accent-2">
                                            <h5 class="font-1 accent-color">Contact Us</h5>
                                        </div>
                                        <div class="d-flex flex-column gap-3">
                                            <span class="d-flex flex-row align-items-center font-2 gap-3">
                                                <div class="contact-item">
                                                    <i class="rtmicon rtmicon-location fs-4"></i>
                                                </div>
                                                 K-55, Connaught Circus, New Delhi – 110001
                                            </span>
                                            <span class="d-flex flex-row align-items-center font-2 gap-3">
                                                <div class="contact-item">
                                                    <i class="rtmicon rtmicon-envelope fs-4"></i>
                                                </div>
                                                 brg@brgupta.com
                                            </span>
                                            <span class="d-flex flex-row align-items-center font-2 gap-3">
                                                <div class="contact-item">
                                                    <i class="rtmicon rtmicon-classic-phone  fs-4"></i>
                                                </div>
                                                +91 (011) 4350 3680
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section d-flex flex-xl-row flex-column gap-3 justify-content-center py-3">
                    <span class="text-xl-center accent-color text-center fs-6 font-2">
                        Copyright © 2024 Rometheme. All Rights Reserved.
                    </span>
                </div>
            </div>
        </div>
    </footer>

    <script src="js/vendor/bootstrap.bundle.min.js"></script>
    <script src="js/vendor/swiper-bundle.min.js"></script>
    <script src="js/script.js"></script>
    <script src="js/swiper-script.js"></script>
    <script src="js/submit-form.js"></script>
    <script src="js/vendor/isotope.pkgd.min.js"></script>
    <script src="js/video_embedded.js"></script>
    <script src="js/vendor/fslightbox.js"></script>
</body>

</html>