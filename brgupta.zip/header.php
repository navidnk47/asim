<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <!--<link rel="icon" type="image/x-icon" href="image/logo.png">-->
    <title>BR GUPTA</title>
</head>

<body>
    <!-- Scripts -->
    <script src="js/vendor/jquery.min.js"></script>

    <!-- Header -->
    <div class="bg-text-color py-3">
        <div class="r-container">
            <div
                class="d-flex flex-xl-row flex-column justify-content-center justify-content-xl-between text-white align-items-center font-2">
                <span class="d-flex flex-row align-items-center gap-2">
                    <i class="rtmicon rtmicon-classic-phone text-white"></i>
                    +91 (011) 4350 3680
                </span>
                <span class="d-flex flex-row align-items-center gap-2">
                    <i class="rtmicon rtmicon-location text-white"></i>
                    K-55, Connaught Circus, New Delhi – 110001
                </span>
                <span class="d-flex flex-row align-items-center gap-2">
                    <i class="rtmicon rtmicon-envelope text-white"></i>
                    brg@brgupta.com
                </span>
            </div>
        </div>
    </div>
    <header class="sticky-top bg-accent-primary">
        <div class="r-container">
            <nav class="navbar navbar-expand-xl">
                <div class="container-fluid ps-3">
                    <div class="logo-container">
                        <a class="navbar-brand" href="#"><img src="image/brgupta.png" alt="" class="img-fluid"></a>
                    </div>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fa-solid fa-bars-staggered accent-color-2"></i>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav mx-auto mb-2 mb-xl-0 gap-xl-4 gap-1">
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="index.html">Homepage</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    About Us
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="about.php">About Us</a></li>
                                    <li><a class="dropdown-item" href="team.php">Team</a></li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    Services
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="services.html">Services</a></li>
                                    <li><a class="dropdown-item" href="service_detail.html">Service Details</a></li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    Pages
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="price_plan.html">Pricing Plan</a></li>
                                    <li><a class="dropdown-item" href="faq.html">FAQs</a></li>
                                    <li><a class="dropdown-item" href="404.html">404 Error</a></li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    News
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="blog.html">Last Article</a></li>
                                    <li><a class="dropdown-item" href="single_blog.html">Single Post</a></li>
                                </ul>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="contact.html">Contact Us</a>
                            </li>
                        </ul>
                        <div
                            class="d-flex flex-row align-items-center text-xl-start text-center justify-content-center gap-3">
                            <div class="contact-item">
                                <i class="rtmicon rtmicon-classic-phone fs-4"></i>
                            </div>
                            <div class="d-flex flex-column">
                                <span class="font-2">Call any time</span>
                                <span class="font-2">+91 (011) 4350 3680</span>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
        </div>
    </header>
    <!-- End Header -->

    <!-- Main -->
    <main>