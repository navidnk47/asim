<?php require("header.php")?>
        <!-- Banner -->
        <div class="section position-relative" style="background-image: url(image/br_gupta_banner.jpg);">
            <div class="bg-overlay"></div>
            <div class="r-container position-relative py-5" style="z-index: 2;">
                <div class="row row-cols-xl-2 row-cols-1">
                    <div class="col col-xl-7">
                        <div class="d-flex flex-column gap-4 py-5 text-white" style="max-width: 767px;">
                            <span class="font-2 accent-color">Trusted Accountants</span>
                            <h1 class="fw-bold">B.R. Gupta & Co.</h1>
                            <p class="text-white">
                                B.R. Gupta & Co.
is a Firm of Chartered Accountants which aims to synthesize its knowledge and experience for the benefit of its clients by focusing on providing value-added services creating a strong competitive advantage for its clients .
                            </p>
                            <div class="d-flex flex-xl-row flex-column align-items-center gap-4">
                                <a href="contact.html" class="btn btn-accent rounded-2 d-flex flex-row gap-2 px-5 py-3">
                                    Learn More
                                </a>
                                <!--<div class="d-flex flex-row gap-3 align-items-center">-->
                                <!--    <button type="button" class="request-loader" data-bs-toggle="modal"-->
                                <!--        data-bs-target="#e119">-->
                                <!--        <i class="rtmicon rtmicon-play-button ms-1"></i>-->
                                <!--    </button>-->
                                <!--    <span>Watch Video</span>-->
                                <!--</div>-->
                            </div>
                        </div>
                    </div>
                    <div class="col col-xl-5 d-flex align-items-center justify-content-end">
                        <div class="d-flex flex-column gap-2 align-items-center">
                            <div class="border-1 border-start border-accent-color" style="height: 5rem;"></div>
                            <div class="d-flex flex-column gap-2 team mb-xl-0 mb-3 gap-2">
                                <a href="https://www.facebook.com" class="social-item-2">
                                    <i class="fa-brands fa-xs fa-facebook-f"></i>
                                </a>
                                <a href="https://www.twitter.com" class="social-item-2">
                                    <i class="fa-brands fa-xs fa-twitter"></i>
                                </a>
                                <a href="https://www.instagram.com" class="social-item-2">
                                    <i class="fa-brands fa-xs fa-instagram"></i>
                                </a>
                                <a href="https://www.youtube.com" class="social-item-2">
                                    <i class="fa-brands fa-xs fa-youtube"></i>
                                </a>
                            </div>
                            <div class="border-1 border-start border-accent-color" style="height: 5rem;"></div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="modal fade" id="e119" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-xl">
                    <div class="modal-content bg-dark-color">
                        <iframe class="ifr-video" src="https://www.youtube.com/embed/FK2RaJ1EfA8?autoplay=1"></iframe>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section Why Choose Us -->
        <div class="section">
            <div class="r-container">
                <div class="row row-cols-xl-3 row-cols-1">
                    <div class="col mb-3">
                        <div class="card img-hover h-100 shadow">
                            <div class=" d-flex flex-column gap-3 justify-content-center p-5">
                                <div class="icon-box">
                                    <i class="rtmicon rtmicon-chart-line-up" style="font-size: 30px;"></i>
                                </div>
                                <h4 class="accent-color">Grow and scale</h4>
                                <p class="text-color-2">Praesent egestas tristique nibh. Aenean viverra rhoncus pede.
                                    Aenean imperdiet.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-3">
                        <div class="card img-hover h-100 shadow">
                            <div class=" d-flex flex-column gap-3 justify-content-center p-5">
                                <div class="icon-box">
                                    <i class="rtmicon rtmicon-client-happy" style="font-size: 30px;"></i>
                                </div>
                                <h4 class="accent-color">Understand clients</h4>
                                <p class="text-color-2">Praesent egestas tristique nibh. Aenean viverra rhoncus pede.
                                    Aenean imperdiet.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-3">
                        <div class="card img-hover h-100 shadow">
                            <div class=" d-flex flex-column gap-3 justify-content-center p-5">
                                <div class="icon-box">
                                    <i class="rtmicon rtmicon-saving" style="font-size: 30px;"></i>
                                </div>
                                <h4 class="accent-color">Cost-Effective</h4>
                                <p class="text-color-2">Praesent egestas tristique nibh. Aenean viverra rhoncus pede.
                                    Aenean imperdiet.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section About Us -->
        <div class="section pt-0">
            <div class="r-container">
                <div class="row row-cols-xl-2 row-cols-1">
                    <div class="col col-xl-6 mb-3">
                        <div class="overflow-hidden h-100 rounded-3" style="object-fit: cover;">
                            <div class="position-relative h-100 overflow-hidden">
                                <div class="bg-overlay"></div>
                                <div class="position-absolute start-0 top-0 w-100 h-100" style="z-index: 2;">
                                    <div class="d-flex justify-content-center align-items-center h-100">
                                        <button type="button" class="request-loader accent" data-bs-toggle="modal"
                                            data-bs-target="#e119">
                                            <i class="rtmicon rtmicon-play-button ms-1"></i>
                                        </button>
                                    </div>
                                </div>
                                <img src="image/dummy-img-600x800.jpg" alt="image" class="w-100 h-100 img-fluid">
                            </div>
                            <div class="modal fade bg-overlay" id="e119" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered modal-xl">
                                    <div class="modal-content bg-dark-color">
                                        <iframe class="ifr-video"
                                            src="https://www.youtube.com/embed/FK2RaJ1EfA8?autoplay=1"></iframe>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col col-xl-6 px-4 mb-3">
                        <div class="d-flex flex-column gap-4">
                            <span class="font-2 accent-color">About Us</span>
                            <h3 class="fw-bold">We Serving Your Financial Needs</h3>
                            <p>
                                We specialize in providing comprehensive financial services tailored to meet the unique
                                needs of our clients. With a commitment to integrity and innovation.
                            </p>
                            <div class="w-max-content">
                                <a href="about.html" class="btn btn-accent rounded-2 d-flex flex-row gap-2 px-5 py-3">
                                    Learn More
                                </a>
                            </div>
                            <div class="row row-cols-xl-2 row-cols-1">
                                <div class="col mb-3">
                                    <h1 class="accent-color fw-bold number-text">15<sup>+</sup></h1>
                                    <h4 class="accent-color mb-3">Years Experience</h4>
                                    <div class="border-1 border-bottom border-dark w-100"></div>
                                </div>
                                <div class="col mb-3">
                                    <h1 class="accent-color fw-bold number-text">90<sup>%</sup></h1>
                                    <h4 class="accent-color mb-3">Satisfied clients</h4>
                                    <div class="border-1 border-bottom border-dark w-100"></div>
                                </div>
                                <div class="col mb-3">
                                    <h1 class="accent-color fw-bold number-text">85<sup>%</sup></h1>
                                    <h4 class="accent-color">Problem Solved</h4>
                                </div>
                                <div class="col mb-3">
                                    <h1 class="accent-color fw-bold number-text">100<sup>+</sup></h1>
                                    <h4 class="accent-color">Expert Accountants</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section Services -->
        <div class="section bg-accent" style="background-image: url(image/Background.png);">
            <div class="r-container">
                <div class="row row-cols-xl-3 row-cols-1">
                    <div class="col col-xl-4 mb-3">
                        <div class="d-flex flex-column gap-3">
                            <span class="font-2 accent-color">Support Services</span>
                            <h3 class="fw-bold">The Best Option For Your Finances</h3>
                            <p>
                                We specialize in providing comprehensive financial services tailored to meet the unique
                                needs of our clients.
                            </p>
                            <div class="w-max-content">
                                <a href="services.html"
                                    class="btn btn-accent rounded-2 d-flex flex-row gap-2 px-5 py-3">
                                    All Services
                                </a>
                            </div>
                            <div class="d-flex flex-column gap-3 ps-2 mt-3">
                                <div class=" col position-relative">
                                    <div class=" d-flex flex-row customer-container">
                                        <div class="customer-item">
                                            <img src="image/dummy-img-400x400.jpg" class="img-fluid" alt="">
                                        </div>
                                        <div class="customer-item">
                                            <img src="image/dummy-img-400x400.jpg" class="img-fluid" alt="">
                                        </div>
                                        <div class="customer-item">
                                            <img src="image/dummy-img-400x400.jpg" class="img-fluid" alt="">
                                        </div>
                                    </div>
                                </div>
                                <span class="m-0 accent-color">90% Satisfied clients</span>
                            </div>
                        </div>
                    </div>
                    <div class="col col-xl-8 mb-3">
                        <div class="row row-cols-xl-2 row-cols-1">
                            <div class="col mb-3">
                                <div class="card card-service img-hover h-100">
                                    <div class=" d-flex flex-column gap-3 px-4 py-5">
                                        <div class="d-flex flex-row gap-3 align-items-center">
                                            <div class="icon-box-2">
                                                <i class="rtmicon rtmicon-taxation accent-color"
                                                    style="font-size: 60px;"></i>
                                            </div>
                                            <h4 class="accent-color">Tax planning</h4>
                                        </div>
                                        <p class="m-0">Our payroll processing services take the hassle out of managing
                                            your payroll, allowing you to focus on running your business.</p>
                                        <a href="service_detail.html" class="read-more">
                                            <div class="d-flex flex-row gap-3 align-items-center">
                                                <span>Read More</span>
                                                <i class="rtmicon rtmicon-chevron-right fs-6 fw-bold"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col mb-3">
                                <div class="card card-service img-hover h-100">
                                    <div class=" d-flex flex-column gap-3 px-4 py-5">
                                        <div class="d-flex flex-row gap-3 align-items-center">
                                            <div class="icon-box-2">
                                                <i class="rtmicon rtmicon-taxes accent-color"
                                                    style="font-size: 60px;"></i>
                                            </div>
                                            <h4 class="accent-color">Audit services</h4>
                                        </div>
                                        <p class="m-0">Our payroll processing services take the hassle out of managing
                                            your payroll, allowing you to focus on running your business.</p>
                                        <a href="service_detail.html" class="read-more">
                                            <div class="d-flex flex-row gap-3 align-items-center">
                                                <span>Read More</span>
                                                <i class="rtmicon rtmicon-chevron-right fs-6 fw-bold"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col mb-3">
                                <div class="card card-service img-hover h-100">
                                    <div class=" d-flex flex-column gap-3 px-4 py-5">
                                        <div class="d-flex flex-row gap-3 align-items-center">
                                            <div class="icon-box-2">
                                                <i class="rtmicon rtmicon-tax-law accent-color"
                                                    style="font-size: 60px;"></i>
                                            </div>
                                            <h4 class="accent-color">Tax strategy</h4>
                                        </div>
                                        <p class="m-0">Our payroll processing services take the hassle out of managing
                                            your payroll, allowing you to focus on running your business.</p>
                                        <a href="service_detail.html" class="read-more">
                                            <div class="d-flex flex-row gap-3 align-items-center">
                                                <span>Read More</span>
                                                <i class="rtmicon rtmicon-chevron-right fs-6 fw-bold"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col mb-3">
                                <div class="card card-service img-hover h-100">
                                    <div class=" d-flex flex-column gap-3 px-4 py-5">
                                        <div class="d-flex flex-row gap-3 align-items-center">
                                            <div class="icon-box-2">
                                                <i class="rtmicon rtmicon-money-check accent-color"
                                                    style="font-size: 60px;"></i>
                                            </div>
                                            <h4 class="accent-color">Bookkeeping</h4>
                                        </div>
                                        <p class="m-0">Our payroll processing services take the hassle out of managing
                                            your payroll, allowing you to focus on running your business.</p>
                                        <a href="service_detail.html" class="read-more">
                                            <div class="d-flex flex-row gap-3 align-items-center">
                                                <span>Read More</span>
                                                <i class="rtmicon rtmicon-chevron-right fs-6 fw-bold"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Team -->
        <div class="section">
            <div class="r-container">
                <div class="d-flex flex-column gap-4 align-items-center">
                    <div class="d-flex flex-column gap-3 text-center align-items-center" style="max-width: 667px;">
                        <span class="font-2 accent-color">Our Team</span>
                        <h3 class="fw-bold">Meet Our Accountants Experts</h3>
                        <p>
                            We specialize in providing comprehensive financial services tailored to meet the unique
                            needs of our clients.
                        </p>
                    </div>
                    <div class="row row-cols-xl-3 row-cols-1">
                        <div class="col mb-3">
                            <img src="image/dummy-img-600x700.jpg" alt="image" class="img-fluid rounded-top-3 w-100">
                            <div
                                class="bg-accent-color d-flex flex-column text-white p-4 align-items-center text-center rounded-bottom-3">
                                <div class="mb-2">
                                    <h5>Ryan Collin</h5>
                                    <span class="font-2">Senior Accountant</span>
                                </div>
                                <div class="social-container team gap-2">
                                    <a href="https://www.facebook.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-facebook-f"></i>
                                    </a>
                                    <a href="https://www.twitter.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-twitter"></i>
                                    </a>
                                    <a href="https://www.instagram.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-instagram"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-3">
                            <img src="image/dummy-img-600x700.jpg" alt="image" class="img-fluid rounded-top-3 w-100">
                            <div
                                class="bg-accent-color d-flex flex-column text-white p-4 align-items-center text-center rounded-bottom-3">
                                <div class="mb-2">
                                    <h5>Rihanna Cloudy</h5>
                                    <span class="font-2">Budget Analyst</span>
                                </div>
                                <div class="social-container team gap-2">
                                    <a href="https://www.facebook.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-facebook-f"></i>
                                    </a>
                                    <a href="https://www.twitter.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-twitter"></i>
                                    </a>
                                    <a href="https://www.instagram.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-instagram"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-3">
                            <img src="image/dummy-img-600x700.jpg" alt="image" class="img-fluid rounded-top-3 w-100">
                            <div
                                class="bg-accent-color d-flex flex-column text-white p-4 align-items-center text-center rounded-bottom-3">
                                <div class="mb-2">
                                    <h5>Abraham Deanz</h5>
                                    <span class="font-2">Tax Expert</span>
                                </div>
                                <div class="social-container team gap-2">
                                    <a href="https://www.facebook.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-facebook-f"></i>
                                    </a>
                                    <a href="https://www.twitter.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-twitter"></i>
                                    </a>
                                    <a href="https://www.instagram.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-instagram"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="w-max-content">
                        <a href="team.html" class="btn btn-accent rounded-2 d-flex flex-row gap-2 px-5 py-3">
                            All Team
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section CTA -->
        <div class="section position-relative bg-attach-fixed"
            style="background-image: url(image/dummy-img-1920x900.jpg); height: 70vh;">
            <div class="bg-overlay"></div>
            <div class="r-container h-100 position-relative" style="z-index: 2;">
                <div class="d-flex flex-column mx-auto text-center w-100 h-100 justify-content-center align-items-center text-white gap-4"
                    style="max-width: 767px;">
                    <h3 class="font-1 text-white">Achieve Financial Freedom
                        Book a Free Assessment Now!</h3>
                    <p class="text-white" style="max-width: 667px;">
                        We specialize in providing comprehensive financial services tailored to meet the unique needs of
                        our clients.
                    </p>
                    <div class="w-max-content">
                        <a href="contact.html" class="btn btn-accent rounded-2 d-flex flex-row gap-2 px-5 py-3">
                            Contact Us
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section Pricing Plan -->
        <div class="section">
            <div class="r-container">
                <div class="d-flex flex-column gap-4 align-items-center">
                    <div class="row row-cols-xl-2 row-cols-1 align-items-center">
                        <div class="col">
                            <span class="font-2 accent-color">Pricing Plan</span>
                            <h3 class="fw-bold">The Best Price For You</h3>
                        </div>
                        <div class="col">
                            <p>
                                We specialize in providing comprehensive financial services tailored to meet the unique
                                needs of our clients.
                            </p>
                        </div>
                    </div>
                    <div class="row row-cols-xl-3 row-cols-1">
                        <div class="col mb-3">
                            <div class="card card-outline-hover h-100 p-5">
                                <div class="d-flex flex-column gap-3">
                                    <div class="d-flex flex-row justify-content-between align-items-center">
                                        <div class="d-flex flex-column gap-3">
                                            <h5 class="accent-color fw-semibold">Starter</h5>
                                            <div class="d-flex flex-row align-items-end heading mb-3">
                                                <h3 class="m-0 fw-bold">$49</h3>
                                                <span class="fw-semibold">/Month</span>
                                            </div>
                                        </div>
                                        <div class="icon-box-2">
                                            <i class="rtmicon rtmicon-money-bill accent-color"
                                                style="font-size: 60px;"></i>
                                        </div>
                                    </div>
                                    <span class="text-color-2">Nam ultrices lacus interdum neque sagittis met Integer
                                        porta sem eu facilisis.</span>
                                    <div class="d-flex flex-column gap-2">
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Morbi aliquet ex sit amet pretium.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Vivamus sit amet erat turpis.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Phasellus eu porta dolor.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Nam mattis pellentesque sem.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Pellentesque lorem est.
                                        </div>
                                    </div>
                                    <div class="w-100">
                                        <a href="contact.html"
                                            class="btn btn-accent rounded-2 d-flex flex-row gap-2 px-5 py-3">
                                            Get Started
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-3">
                            <div class="card card-outline-hover h-100 p-5">
                                <div class="d-flex flex-column gap-3">
                                    <div class="d-flex flex-row justify-content-between align-items-center">
                                        <div class="d-flex flex-column gap-3">
                                            <h5 class="accent-color fw-semibold">Enterprise</h5>
                                            <div class="d-flex flex-row align-items-end heading mb-3">
                                                <h3 class="m-0 fw-bold">$129</h3>
                                                <span class="fw-semibold">/Month</span>
                                            </div>
                                        </div>
                                        <div class="icon-box-2">
                                            <i class="rtmicon rtmicon-money-bill accent-color"
                                                style="font-size: 60px;"></i>
                                        </div>
                                    </div>
                                    <span class="text-color-2">Nam ultrices lacus interdum neque sagittis met Integer
                                        porta sem eu facilisis.</span>
                                    <div class="d-flex flex-column gap-2">
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Morbi aliquet ex sit amet pretium.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Vivamus sit amet erat turpis.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Phasellus eu porta dolor.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Nam mattis pellentesque sem.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Pellentesque lorem est.
                                        </div>
                                    </div>
                                    <div class="w-100">
                                        <a href="contact.html"
                                            class="btn btn-accent rounded-2 d-flex flex-row gap-2 px-5 py-3">
                                            Get Started
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-3">
                            <div class="card card-outline-hover h-100 p-5">
                                <div class="d-flex flex-column gap-3">
                                    <div class="d-flex flex-row justify-content-between align-items-center">
                                        <div class="d-flex flex-column gap-3">
                                            <h5 class="accent-color fw-semibold">Professional</h5>
                                            <div class="d-flex flex-row align-items-end heading mb-3">
                                                <h3 class="m-0 fw-bold">$90</h3>
                                                <span class="fw-semibold">/Month</span>
                                            </div>
                                        </div>
                                        <div class="icon-box-2">
                                            <i class="rtmicon rtmicon-money-bill accent-color"
                                                style="font-size: 60px;"></i>
                                        </div>
                                    </div>
                                    <span class="text-color-2">Nam ultrices lacus interdum neque sagittis met Integer
                                        porta sem eu facilisis.</span>
                                    <div class="d-flex flex-column gap-2">
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Morbi aliquet ex sit amet pretium.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Vivamus sit amet erat turpis.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Phasellus eu porta dolor.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Nam mattis pellentesque sem.
                                        </div>
                                        <div class="d-flex flex-row gap-3 align-items-center text-color-2">
                                            <i class="fa-solid fa-circle-check accent-color"></i>
                                            Pellentesque lorem est.
                                        </div>
                                    </div>
                                    <div class="w-100">
                                        <a href="contact.html"
                                            class="btn btn-accent rounded-2 d-flex flex-row gap-2 px-5 py-3">
                                            Get Started
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section Partner -->
        <div class="section bg-accent">
            <div class="r-container">
                <div class="swiper swiperImage">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide p-0">
                            <div class="d-flex justify-content-center">
                                <img src="image/Logo 1.png" class="img-fluid" alt="image">
                            </div>
                        </div>
                        <div class="swiper-slide p-0">
                            <div class="d-flex justify-content-center">
                                <img src="image/Logo 2.png" class="img-fluid " alt="image">
                            </div>
                        </div>
                        <div class="swiper-slide p-0">
                            <div class="d-flex justify-content-center">
                                <img src="image/Logo 3.png" class="img-fluid" alt="image">
                            </div>
                        </div>
                        <div class="swiper-slide p-0">
                            <div class="d-flex justify-content-center">
                                <img src="image/Logo 4.png" class="img-fluid" alt="image">
                            </div>
                        </div>
                        <div class="swiper-slide p-0">
                            <div class="d-flex justify-content-center">
                                <img src="image/Logo 5.png" class="img-fluid" alt="image">
                            </div>
                        </div>
                        <div class="swiper-slide p-0">
                            <div class="d-flex justify-content-center">
                                <img src="image/Logo 6.png" class="img-fluid" alt="image">
                            </div>
                        </div>
                        <div class="swiper-slide p-0">
                            <div class="d-flex justify-content-center">
                                <img src="image/Logo 7.png" class="img-fluid" alt="image">
                            </div>
                        </div>
                    </div>
                    <!-- If we need pagination -->
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </div>

        <!-- FAQs -->
        <div class="section">
            <div class="r-container d-flex flex-column gap-4">
                <div class="d-flex flex-column gap-3 text-center mx-auto align-items-center" style="max-width: 667px;">
                    <span class="font-2 accent-color">FAQs</span>
                    <h3 class="fw-bold">Frequently Asked Questions</h3>
                    <p>
                        We specialize in providing comprehensive financial services tailored to meet the unique
                        needs of our clients.
                    </p>
                </div>
                <div class="row row-cols-xl-2 row-cols-1">
                    <div class="col px-4 mb-3">
                        <div class="d-flex flex-column gap-4 pe-xl-5 pb-5">
                            <div class="accordion mt-3 d-flex flex-column gap-4" id="faqAccordion1">
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#faq1" aria-expanded="true" aria-controls="faq1">
                                            What services do accounting firms offer?
                                        </button>
                                    </h2>
                                    <div id="faq1" class="accordion-collapse collapse show"
                                        data-bs-parent="#faqAccordion1">
                                        <div class="accordion-body">
                                            Fusce mattis dui aliquam dui consectetur, et eleifend eros elit. Donec at
                                            accumsa ligula. Cras vulputate nunc vitae quam lorem ipsm dolor sit amet.
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#faq2" aria-expanded="false"
                                            aria-controls="faq2">
                                            What Is The Accounting Cycle?
                                        </button>
                                    </h2>
                                    <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion1">
                                        <div class="accordion-body">
                                            Fusce mattis dui aliquam dui consectetur, et eleifend eros elit. Donec at
                                            accumsa ligula. Cras vulputate nunc vitae quam lorem ipsm dolor sit amet.
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#faq3" aria-expanded="false"
                                            aria-controls="faq3">
                                            How do I choose the right accounting firm for my business?
                                        </button>
                                    </h2>
                                    <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion1">
                                        <div class="accordion-body">
                                            Fusce mattis dui aliquam dui consectetur, et eleifend eros elit. Donec at
                                            accumsa ligula. Cras vulputate nunc vitae quam lorem ipsm dolor sit amet.
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#faq4" aria-expanded="false"
                                            aria-controls="faq4">
                                            What Service Do You Offer?
                                        </button>
                                    </h2>
                                    <div id="faq4" class="accordion-collapse collapse" data-bs-parent="#faqAccordion1">
                                        <div class="accordion-body">
                                            Fusce mattis dui aliquam dui consectetur, et eleifend eros elit. Donec at
                                            accumsa ligula. Cras vulputate nunc vitae quam lorem ipsm dolor sit amet.
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#faq5" aria-expanded="false"
                                            aria-controls="faq5">
                                            What qualifications should I look for in an accounting firm?
                                        </button>
                                    </h2>
                                    <div id="faq5" class="accordion-collapse collapse" data-bs-parent="#faqAccordion1">
                                        <div class="accordion-body">
                                            Fusce mattis dui aliquam dui consectetur, et eleifend eros elit. Donec at
                                            accumsa ligula. Cras vulputate nunc vitae quam lorem ipsm dolor sit amet.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col px-4 mb-3">
                        <div class="d-flex flex-column gap-4 pe-xl-5 pb-5">
                            <div class="accordion mt-3 d-flex flex-column gap-4" id="faqAccordion2">
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#faq6" aria-expanded="true"
                                            aria-controls="faq6">
                                            What Is The Accounting Cycle?
                                        </button>
                                    </h2>
                                    <div id="faq6" class="accordion-collapse collapse" data-bs-parent="#faqAccordion2">
                                        <div class="accordion-body">
                                            Fusce mattis dui aliquam dui consectetur, et eleifend eros elit. Donec at
                                            accumsa ligula. Cras vulputate nunc vitae quam lorem ipsm dolor sit amet.
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#faq7" aria-expanded="false"
                                            aria-controls="faq7">
                                            How do I choose the right accounting firm for my business?
                                        </button>
                                    </h2>
                                    <div id="faq7" class="accordion-collapse collapse" data-bs-parent="#faqAccordion2">
                                        <div class="accordion-body">
                                            Fusce mattis dui aliquam dui consectetur, et eleifend eros elit. Donec at
                                            accumsa ligula. Cras vulputate nunc vitae quam lorem ipsm dolor sit amet.
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#faq8" aria-expanded="false"
                                            aria-controls="faq8">
                                            What Service Do You Offer?
                                        </button>
                                    </h2>
                                    <div id="faq8" class="accordion-collapse collapse" data-bs-parent="#faqAccordion2">
                                        <div class="accordion-body">
                                            Fusce mattis dui aliquam dui consectetur, et eleifend eros elit. Donec at
                                            accumsa ligula. Cras vulputate nunc vitae quam lorem ipsm dolor sit amet.
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#faq9" aria-expanded="false"
                                            aria-controls="faq9">
                                            What qualifications should I look for in an accounting firm?
                                        </button>
                                    </h2>
                                    <div id="faq9" class="accordion-collapse collapse" data-bs-parent="#faqAccordion2">
                                        <div class="accordion-body">
                                            Fusce mattis dui aliquam dui consectetur, et eleifend eros elit. Donec at
                                            accumsa ligula. Cras vulputate nunc vitae quam lorem ipsm dolor sit amet.
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#faq10" aria-expanded="false" aria-controls="faq10">
                                            What services do accounting firms offer?
                                        </button>
                                    </h2>
                                    <div id="faq10" class="accordion-collapse collapse show"
                                        data-bs-parent="#faqAccordion2">
                                        <div class="accordion-body">
                                            Fusce mattis dui aliquam dui consectetur, et eleifend eros elit. Donec at
                                            accumsa ligula. Cras vulputate nunc vitae quam lorem ipsm dolor sit amet.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Testimonials -->
        <div class="section bg-accent">
            <div class="r-container d-flex flex-column gap-4">
                <div class="row row-cols-xl-2 row-cols-1">
                    <div class="col col-xl-5 mb-3">
                        <img src="image/dummy-img-600x700.jpg" class="img-fluid rounded-3 h-100" alt="">
                    </div>
                    <div class="col col-xl-7 mb-3">
                        <div class="d-flex flex-column gap-3 mx-auto" style="max-width: 667px;">
                            <span class="font-2 accent-color">Testimonials</span>
                            <h3 class="fw-bold">Client Testimonials Highlighting Pluz's Impact</h3>
                            <p>
                                We specialize in providing comprehensive financial services tailored to meet the unique
                                needs of our clients.
                            </p>
                        </div>
                        <div class="overflow-hidden floating-left mt-3">
                            <div class="swiper swiperTestimonials">
                                <!-- Additional required wrapper -->
                                <div class="swiper-wrapper">
                                    <!-- Slides -->
                                    <div class="swiper-slide">
                                        <div
                                            class="testimonial-container text-white px-5 py-5 border border-1 border-accent-color rounded-3 justify-content-between">
                                            <div class="d-flex flex-column gap-3">
                                                <span class="font-2 fst-italic">"“Working with Pluz Accounting has been
                                                    a game-changer for our small business. Their meticulous attention to
                                                    detail and proactive tax planning have saved us.”</span>
                                                <div class="d-flex flex-row justify-content-between align-items-center">
                                                    <div class="d-flex flex-row align-items-center gap-3">
                                                        <div class="testimonial-item">
                                                            <img src="image/dummy-img-400x400.jpg"
                                                                class="img-fluid border-light" alt="">
                                                        </div>
                                                        <div class="d-flex flex-column">
                                                            <h5>Sarah Laura</h5>
                                                            <span class="font-2 text-color-2">Designation</span>
                                                            <div class="flex-row">
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star"
                                                                    style="color: var(--text-color-1);"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <i class="rtmicon rtmicon-blockquote fw-bold accent fs-1"></i>
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div
                                            class="testimonial-container text-white px-5 py-5 border border-1 border-accent-color rounded-3 justify-content-between">
                                            <div class="d-flex flex-column gap-3">
                                                <span class="font-2 fst-italic">"“Working with Pluz Accounting has been
                                                    a game-changer for our small business. Their meticulous attention to
                                                    detail and proactive tax planning have saved us.”</span>
                                                <div class="d-flex flex-row justify-content-between align-items-center">
                                                    <div class="d-flex flex-row align-items-center gap-3">
                                                        <div class="testimonial-item">
                                                            <img src="image/dummy-img-400x400.jpg"
                                                                class="img-fluid border-light" alt="">
                                                        </div>
                                                        <div class="d-flex flex-column">
                                                            <h5>Thomas Roy</h5>
                                                            <span class="font-2 text-color-2">Designation</span>
                                                            <div class="flex-row">
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star"
                                                                    style="color: var(--text-color-1);"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <i class="rtmicon rtmicon-blockquote fw-bold accent fs-1"></i>
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div
                                            class="testimonial-container text-white px-5 py-5 border border-1 border-accent-color rounded-3 justify-content-between">
                                            <div class="d-flex flex-column gap-3">
                                                <span class="font-2 fst-italic">"“Working with Pluz Accounting has been
                                                    a game-changer for our small business. Their meticulous attention to
                                                    detail and proactive tax planning have saved us.”</span>
                                                <div class="d-flex flex-row justify-content-between align-items-center">
                                                    <div class="d-flex flex-row align-items-center gap-3">
                                                        <div class="testimonial-item">
                                                            <img src="image/dummy-img-400x400.jpg"
                                                                class="img-fluid border-light" alt="">
                                                        </div>
                                                        <div class="d-flex flex-column">
                                                            <h5>John Thunder</h5>
                                                            <span class="font-2 text-color-2">Designation</span>
                                                            <div class="flex-row">
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                                                <i class="fa-solid fa-star"
                                                                    style="color: var(--text-color-1);"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <i class="rtmicon rtmicon-blockquote fw-bold accent fs-1"></i>
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <!-- If we need pagination -->
                                <div class="swiper-pagination"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Blog -->
        <div class="section">
            <div class="r-container d-flex flex-column align-items-center gap-4">
                <div class="d-flex flex-column gap-3 mx-auto text-center align-items-center justify-content-center"
                    style="max-width: 567px;">
                    <span class="font-2 accent-color">Blog & News</span>
                    <h3 class="fw-bold">Our Latest Article</h3>
                    <p>
                        Tristirue nulla aliquet enim tortor at auctor urnanmassa enim nec dui nunc mattis enim ut
                        tellusnaute irure repreaen. 
                    </p>
                </div>
                <div class="d-flex flex-xl-row flex-column-reverse gap-3">
                    <div class="col mb-3">
                        <div class="card d-flex flex-column gap-3">
                            <div class="position-relative">
                                <img src="image/dummy-img-600x400.jpg" alt="image" class="img-fluid rounded-3">
                                <div class="position-absolute d-flex flex-column align-items-center bottom-0 end-0 px-4 py-2 bg-accent-color rounded-2"
                                    style="margin-bottom: -2rem; margin-right: 1rem;">
                                    <span class="text-white">09</span>
                                    <span class="text-white">July</span>

                                </div>
                            </div>
                            <div class="d-flex flex-column gap-1 mt-4">
                                <h5>Navigating Tax Season: Essential Tips for Small Businesses</h5>
                                <p class="text-color-2">Rostrum exercitationem ullam corporis suscipit lorem laboriosam,
                                    nisiae commodi consenuatur.
                                </p>
                                <a href="single_blog.html" class="font-1 fs-6 fw-semibold accent-color read-more">Read
                                    More <i class="rtmicon rtmicon-chevron-right fs-6 fw-bold"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-3">
                        <div class="card d-flex flex-column gap-3">
                            <div class="position-relative">
                                <img src="image/dummy-img-600x400.jpg" alt="image" class="img-fluid rounded-3">
                                <div class="position-absolute d-flex flex-column align-items-center bottom-0 end-0 px-4 py-2 bg-accent-color rounded-2"
                                    style="margin-bottom: -2rem; margin-right: 1rem;">
                                    <span class="text-white">09</span>
                                    <span class="text-white">July</span>

                                </div>
                            </div>
                            <div class="d-flex flex-column gap-1 mt-4">
                                <h5>The Future of Blockchain in Accounting: Opportunities and Challenges</h5>
                                <p class="text-color-2">Rostrum exercitationem ullam corporis suscipit lorem laboriosam,
                                    nisiae commodi consenuatur.
                                </p>
                                <a href="single_blog.html" class="font-1 fs-6 fw-semibold accent-color read-more">Read
                                    More <i class="rtmicon rtmicon-chevron-right fs-6 fw-bold"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-3">
                        <div class="card d-flex flex-column gap-3">
                            <div class="position-relative">
                                <img src="image/dummy-img-600x400.jpg" alt="image" class="img-fluid rounded-3">
                                <div class="position-absolute d-flex flex-column align-items-center bottom-0 end-0 px-4 py-2 bg-accent-color rounded-2"
                                    style="margin-bottom: -2rem; margin-right: 1rem;">
                                    <span class="text-white">09</span>
                                    <span class="text-white">July</span>

                                </div>
                            </div>
                            <div class="d-flex flex-column gap-1 mt-4">
                                <h5>How AI is Revolutionizing Financial Reporting and Analysis</h5>
                                <p class="text-color-2">Rostrum exercitationem ullam corporis suscipit lorem laboriosam,
                                    nisiae commodi consenuatur.
                                </p>
                                <a href="single_blog.html" class="font-1 fs-6 fw-semibold accent-color read-more">Read
                                    More <i class="rtmicon rtmicon-chevron-right fs-6 fw-bold"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="w-max-content">
                    <a href="blog.html" class="btn btn-accent rounded-2 d-flex flex-row gap-2 px-5 py-3">
                        View All
                    </a>
                </div>
            </div>
        </div>
<?php require("footer.php")?>