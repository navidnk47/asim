<?php require("header.php")?>
        <!-- Banner -->
        <div class="section position-relative"
            style="background-image: url(image/dummy-img-1920x900.jpg); height: 70vh;">
            <div class="bg-overlay"></div>
            <div class="r-container h-100 position-relative" style="z-index: 2;">
                <div class="d-flex flex-column w-100 h-100 justify-content-center mx-auto align-items-center text-white gap-3"
                    style="max-width: 895px;">
                    <h2 class="font-1 m-0 text-white fw-bold">Our Team</h2>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Our Team</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>

        <!-- Team -->
        <div class="section">
            <div class="r-container">
                <div class="d-flex flex-column gap-4 align-items-center">
                    <div class="d-flex flex-column gap-3 text-center align-items-center" style="max-width: 667px;">
                        <span class="font-2 accent-color">Our Team</span>
                        <h3 class="fw-bold">Meet Our Accountants Experts</h3>
                        <p>
                            B. R. Gupta & Co. has a well equipped and competent team. It works using auditing expertise, accounting and taxation knowledge and experience to deliver value and quality. The team comprises of qualified Chartered Accountants, Other Professionals and Support Staff.
                        </p>
                    </div>
                    <div class="row row-cols-xl-3 row-cols-1">
                        <div class="col mb-3">
                            <img src="image/B.R.Gupta.jpg" alt="image" class="img-fluid rounded-top-3 w-100">
                            <div
                                class="bg-accent-color d-flex flex-column text-white p-4 align-items-center text-center rounded-bottom-3">
                                <div class="mb-2">
                                    <h5>Mr. B.R. Gupta</h5>
                                    <span class="font-2">Senior Accountant</span>
                                </div>
                                <div class="social-container team gap-2">
                                    <a href="https://www.facebook.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-facebook-f"></i>
                                    </a>
                                    <a href="https://www.twitter.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-twitter"></i>
                                    </a>
                                    <a href="https://www.instagram.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-instagram"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-3">
                            <img src="image/dummy-img-600x700.jpg" alt="image" class="img-fluid rounded-top-3 w-100">
                            <div
                                class="bg-accent-color d-flex flex-column text-white p-4 align-items-center text-center rounded-bottom-3">
                                <div class="mb-2">
                                    <h5>Mr. Deepak Jain</h5>
                                    <span class="font-2">Budget Analyst</span>
                                </div>
                                <div class="social-container team gap-2">
                                    <a href="https://www.facebook.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-facebook-f"></i>
                                    </a>
                                    <a href="https://www.twitter.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-twitter"></i>
                                    </a>
                                    <a href="https://www.instagram.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-instagram"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-3">
                            <img src="image/dummy-img-600x700.jpg" alt="image" class="img-fluid rounded-top-3 w-100">
                            <div
                                class="bg-accent-color d-flex flex-column text-white p-4 align-items-center text-center rounded-bottom-3">
                                <div class="mb-2">
                                    <h5>Mr. Deepak Agarwal</h5>
                                    <span class="font-2">Tax Expert</span>
                                </div>
                                <div class="social-container team gap-2">
                                    <a href="https://www.facebook.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-facebook-f"></i>
                                    </a>
                                    <a href="https://www.twitter.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-twitter"></i>
                                    </a>
                                    <a href="https://www.instagram.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-instagram"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row row-cols-xl-3 row-cols-1">
                        <div class="col mb-3">
                            <img src="image/dummy-img-600x700.jpg" alt="image" class="img-fluid rounded-top-3 w-100">
                            <div
                                class="bg-accent-color d-flex flex-column text-white p-4 align-items-center text-center rounded-bottom-3">
                                <div class="mb-2">
                                    <h5>Mr. Ashwani Kumar Mishra</h5>
                                    <span class="font-2">Accountant</span>
                                </div>
                                <div class="social-container team gap-2">
                                    <a href="https://www.facebook.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-facebook-f"></i>
                                    </a>
                                    <a href="https://www.twitter.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-twitter"></i>
                                    </a>
                                    <a href="https://www.instagram.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-instagram"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-3">
                            <img src="image/dummy-img-600x700.jpg" alt="image" class="img-fluid rounded-top-3 w-100">
                            <div
                                class="bg-accent-color d-flex flex-column text-white p-4 align-items-center text-center rounded-bottom-3">
                                <div class="mb-2">
                                    <h5>Ms. Shikha Aggarwal</h5>
                                    <span class="font-2">Financial Manager</span>
                                </div>
                                <div class="social-container team gap-2">
                                    <a href="https://www.facebook.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-facebook-f"></i>
                                    </a>
                                    <a href="https://www.twitter.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-twitter"></i>
                                    </a>
                                    <a href="https://www.instagram.com" class="social-item">
                                        <i class="fa-brands fa-xs fa-instagram"></i>
                                    </a>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <!-- Section Partner -->
        <div class="section bg-accent">
            <div class="r-container">
                <div class="swiper swiperImage">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide p-0">
                            <div class="d-flex justify-content-center">
                                <img src="image/Logo 1.png" class="img-fluid" alt="image">
                            </div>
                        </div>
                        <div class="swiper-slide p-0">
                            <div class="d-flex justify-content-center">
                                <img src="image/Logo 2.png" class="img-fluid " alt="image">
                            </div>
                        </div>
                        <div class="swiper-slide p-0">
                            <div class="d-flex justify-content-center">
                                <img src="image/Logo 3.png" class="img-fluid" alt="image">
                            </div>
                        </div>
                        <div class="swiper-slide p-0">
                            <div class="d-flex justify-content-center">
                                <img src="image/Logo 4.png" class="img-fluid" alt="image">
                            </div>
                        </div>
                        <div class="swiper-slide p-0">
                            <div class="d-flex justify-content-center">
                                <img src="image/Logo 5.png" class="img-fluid" alt="image">
                            </div>
                        </div>
                        <div class="swiper-slide p-0">
                            <div class="d-flex justify-content-center">
                                <img src="image/Logo 6.png" class="img-fluid" alt="image">
                            </div>
                        </div>
                        <div class="swiper-slide p-0">
                            <div class="d-flex justify-content-center">
                                <img src="image/Logo 7.png" class="img-fluid" alt="image">
                            </div>
                        </div>
                    </div>
                    <!-- If we need pagination -->
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </div>

        <!-- Section Services -->
        <div class="section" style="background-image: url(image/Background.png);">
            <div class="r-container">
                <div class="row row-cols-xl-3 row-cols-1">
                    <div class="col col-xl-4 mb-3">
                        <div class="d-flex flex-column gap-3">
                            <span class="font-2 accent-color">Support Services</span>
                            <h3 class="fw-bold">The Best Option For Your Finances</h3>
                            <p>
                                We specialize in providing comprehensive financial services tailored to meet the unique
                                needs of our clients.
                            </p>
                            <div class="w-max-content">
                                <a href="services.html"
                                    class="btn btn-accent rounded-2 d-flex flex-row gap-2 px-5 py-3">
                                    All Services
                                </a>
                            </div>
                            <div class="d-flex flex-column gap-3 ps-2 mt-3">
                                <div class=" col position-relative">
                                    <div class=" d-flex flex-row customer-container">
                                        <div class="customer-item">
                                            <img src="image/dummy-img-400x400.jpg" class="img-fluid" alt="">
                                        </div>
                                        <div class="customer-item">
                                            <img src="image/dummy-img-400x400.jpg" class="img-fluid" alt="">
                                        </div>
                                        <div class="customer-item">
                                            <img src="image/dummy-img-400x400.jpg" class="img-fluid" alt="">
                                        </div>
                                    </div>
                                </div>
                                <span class="m-0 accent-color">90% Satisfied clients</span>
                            </div>
                        </div>
                    </div>
                    <div class="col col-xl-8 mb-3">
                        <div class="row row-cols-xl-2 row-cols-1">
                            <div class="col mb-3">
                                <div class="card card-service img-hover h-100 shadow">
                                    <div class=" d-flex flex-column gap-3 px-4 py-5">
                                        <div class="d-flex flex-row gap-3 align-items-center">
                                            <div class="icon-box-2">
                                                <i class="rtmicon rtmicon-taxation accent-color"
                                                    style="font-size: 60px;"></i>
                                            </div>
                                            <h4 class="accent-color">Tax planning</h4>
                                        </div>
                                        <p class="m-0">Our payroll processing services take the hassle out of managing
                                            your payroll, allowing you to focus on running your business.</p>
                                        <a href="service_detail.html" class="read-more">
                                            <div class="d-flex flex-row gap-3 align-items-center">
                                                <span>Read More</span>
                                                <i class="rtmicon rtmicon-chevron-right fs-6 fw-bold"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col mb-3">
                                <div class="card card-service img-hover h-100 shadow">
                                    <div class=" d-flex flex-column gap-3 px-4 py-5">
                                        <div class="d-flex flex-row gap-3 align-items-center">
                                            <div class="icon-box-2">
                                                <i class="rtmicon rtmicon-taxes accent-color"
                                                    style="font-size: 60px;"></i>
                                            </div>
                                            <h4 class="accent-color">Audit services</h4>
                                        </div>
                                        <p class="m-0">Our payroll processing services take the hassle out of managing
                                            your payroll, allowing you to focus on running your business.</p>
                                        <a href="service_detail.html" class="read-more">
                                            <div class="d-flex flex-row gap-3 align-items-center">
                                                <span>Read More</span>
                                                <i class="rtmicon rtmicon-chevron-right fs-6 fw-bold"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col mb-3">
                                <div class="card card-service img-hover h-100 shadow">
                                    <div class=" d-flex flex-column gap-3 px-4 py-5">
                                        <div class="d-flex flex-row gap-3 align-items-center">
                                            <div class="icon-box-2">
                                                <i class="rtmicon rtmicon-tax-law accent-color"
                                                    style="font-size: 60px;"></i>
                                            </div>
                                            <h4 class="accent-color">Tax strategy</h4>
                                        </div>
                                        <p class="m-0">Our payroll processing services take the hassle out of managing
                                            your payroll, allowing you to focus on running your business.</p>
                                        <a href="service_detail.html" class="read-more">
                                            <div class="d-flex flex-row gap-3 align-items-center">
                                                <span>Read More</span>
                                                <i class="rtmicon rtmicon-chevron-right fs-6 fw-bold"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col mb-3">
                                <div class="card card-service img-hover h-100 shadow">
                                    <div class=" d-flex flex-column gap-3 px-4 py-5">
                                        <div class="d-flex flex-row gap-3 align-items-center">
                                            <div class="icon-box-2">
                                                <i class="rtmicon rtmicon-money-check accent-color"
                                                    style="font-size: 60px;"></i>
                                            </div>
                                            <h4 class="accent-color">Bookkeeping</h4>
                                        </div>
                                        <p class="m-0">Our payroll processing services take the hassle out of managing
                                            your payroll, allowing you to focus on running your business.</p>
                                        <a href="service_detail.html" class="read-more">
                                            <div class="d-flex flex-row gap-3 align-items-center">
                                                <span>Read More</span>
                                                <i class="rtmicon rtmicon-chevron-right fs-6 fw-bold"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php require("footer.php")?>